import { ScriptEventSource } from "@minecraft/server"
import Config from "../Configuration"
import CommandBuilder from "../Modules/CommandBuilder"
import { getCooldown, setCooldown } from "../Modules/Cooldown"
import { Log } from "../Modules/Log"

/**
 * @param {import("../main").default} Server
 */
const chatSend = (Server) => {
  Server.Minecraft.world.beforeEvents.chatSend.subscribe(async (data) => {
    if (data.sender.isMuted()) {
      data.cancel = true;
      return data.sender.sendMessage({ translate: "mce.player.muted" });
    }

    let player = data.sender;
    let message = data.message;

    // Log chat messages directly to the BDS console
    console.warn(`[CHAT] ${player.name}: ${message}`);

    let prefix = Server.getPrefix();
    if (message.startsWith(prefix)) {
      let args = data.message.slice(prefix.length).trim().split(" ");
      let command = args.shift().toLowerCase();
      let cmd = Server.Commands.getAllRegistation().find(
        (c) => c.name == command || (c.aliases && c.aliases.includes(command))
      );

      data.cancel = true;
      if (getCooldown("command", player) > 0)
        return player.sendMessage({
          translate: "mce.player.command.oncooldown",
          with: [`${getCooldown("command", player)}`],
        });

      if (!cmd)
        return player.sendMessage({ translate: "mce.command.unknown", with: [command] });

      player.runCommandAsync(`scriptevent ${cmd.id}:runCommand ${command} ${args.join(" ")}`);
      setCooldown("command", player, player.getPermission("command.cooldown"));
      Log({ translate: "mce.log.commandused", with: [player.name, cmd.name] });
    }

    if (getCooldown("chat", player) > 0) {
      data.cancel = true;
      return player.sendMessage({ translate: "mce.player.chat.cooldown" });
    }

    setCooldown("chat", player, player.getPermission("chat.cooldown"));
  });
};

export default chatSend;
