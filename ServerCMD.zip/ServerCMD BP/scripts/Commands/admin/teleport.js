/**
 * @param {import("../../main").default} Server 
 */
const teleport = (Server) => {
  Server.Commands.register({
    name: "teleport",
    description: "Teleport to player",
    usage: "teleport <player_name>",
    permission: "teleport",
    aliases: ["tp"],
    category: "Admin"
  }, async (data, player, args) => {
    if (!args[0]) return player.sendMessage({ translate: "mce.command.inputplayer" })
    let targetPlayer = Server.getPlayer(args[0])
    if (targetPlayer != undefined) {
      player.runCommandAsync(`tp "${targetPlayer.name}"`)
      .catch(() => {
        player.sendMessage("§cTeleport failed.")
      })
      .then(() => {
        player.sendMessage("§aTeleport successful.")
      })
    } else {
      player.sendMessage({ translate: "mce.command.target.unknown" })
    }
  })
}

export default teleport