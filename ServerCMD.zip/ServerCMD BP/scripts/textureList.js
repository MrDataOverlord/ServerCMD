// This is used for set texture on custom items (Doesn't work for custom block)

export const TextureList = {
  "custom item id here": "texture path here",
  "paoitem:example": "textures/items/stick",
  "pao:claimblock1": "textures/items/claimblock1",
  "pao:claimblock10": "textures/items/claimblock10",
  "pao:claimblock100": "textures/items/claimblock100"
}